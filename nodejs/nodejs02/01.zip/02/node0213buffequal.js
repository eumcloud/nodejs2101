var buf1 = Buffer.from('abcd');
var buf2 = Buffer.from('abcd');

console.log(buf1.equals(buf2));// true
