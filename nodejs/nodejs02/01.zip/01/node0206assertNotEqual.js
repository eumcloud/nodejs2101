var assert = require("assert");

assert.notEqual(50, 70); //OK
console.log("Hello world!!!");
assert.notEqual(50, 50); //Error