var assert = require('assert');
assert( 5> 7); //true 이면 빠져나와서 다음구문실행하고, false면 에러띄움
console.log("hello world!!!");

